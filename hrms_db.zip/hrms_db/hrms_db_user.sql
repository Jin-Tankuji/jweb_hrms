-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: hrms_db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` varchar(255) NOT NULL,
  `employee_id` varchar(45) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `fk_empID_user_idx` (`employee_id`),
  CONSTRAINT `fk_empID_user` FOREIGN KEY (`employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('0090064c-c31d-4e89-aab4-ed05b37be58a','DEV0224','ductin2003','$2a$10$uMR/Qw68qbyZSa84c7k7qeJTdp2O82K1BIqRRrGmI6J3zNtSeu1D.','MEMBER'),('938f32bd-8a10-4898-b713-9c64eb5902c0',NULL,'admin','$2a$10$W9gL928VnzAMmpczReK4geTLzDNQKYVUF0SgFpH6ba3FVN3tz7ph6','ADMIN'),('abc2f75a-63c5-4380-b0a0-2f8b575964d3','DEV0324','dredk2000','12345678','MEMBER'),('c464cece-4e85-4d6f-af3e-6dc2c3506537','SAL0224','lamnguyn1908','$2a$10$x/hQdknHLiagQpLZp2mZBODkZ5EKLHLoRylRqS7rYpKCE7yZ2cvn.','MEMBER'),('c6704f44-9e8d-4792-a493-4fe6cf464f80','DEV0124','nhhai2003','$2a$10$f6DwxfQtJbAoeFaTiq3.f.rw2DBUYc9U2Qlg0lhvBp8izJlAo7Aye','MEMBER, ADMIN'),('deeb71b6-da65-448d-b4e4-b66d7c921338','SAL0124','hhieu2002','$2a$10$H/zm/VJPS08e06tHwUmH8e5PcZ/JySnUDKJshS6tUJNBLZ.CdFhFW','MEMBER');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-26 18:38:44
